#!/bin/bash
# Remove the Exxos Global Theme package itself.
# Bundled components installed into ~/.local/share are left in place on purpose:
# other themes or a previous setup may be using them. Delete them by hand if
# you are certain nothing else needs them:
#   ~/.local/share/aurorae/themes/exposeair
#   ~/.local/share/plasma/desktoptheme/Exxos
#   ~/.local/share/color-schemes/Exxos.colors
set -e
rm -rf "$HOME/.local/share/plasma/look-and-feel/com.exxos.win7"
echo "Removed the Exxos Global Theme package."
echo "Switch to another Global Theme in System Settings if Exxos is still active."
