# Exxos panel widget patches

Three Plasma widgets are modified for the Exxos look:

| Widget | Change | Lines |
|---|---|---|
| `org.kde.plasma.icon` | fixed 38 px quick-launch slot; upstream hardcodes the icon square to panel height with no setting that reaches it | 22 |
| `org.kde.plasma.showdesktop` | same, it otherwise falls back to panel height | 12 |
| `org.kde.plasma.kicker` | white backdrop + dark text on the start menu and its submenus, to match `menu7.PNG` | 46 |

## Why patches instead of copied files

A plasmoid in `~/.local/share/plasma/plasmoids/` shadows the system one
**entirely** — Plasma resolves the whole package from a single location, so a
single file cannot be overridden.

The original approach copied the whole package: **4738 lines shadowed to change
80**. After a Plasma upgrade those stale copies still win, and the failure is
**silent** — no error, just a widget misbehaving against a newer Plasma.

These scripts instead copy the system plasmoid *as installed today* and reapply
only the 80 lines.

## Usage

```bash
./rebuild-overrides.sh --check   # do the patches still apply? changes nothing
./rebuild-overrides.sh           # rebuild against the current Plasma
```

Previous overrides are moved to `superseded/<timestamp>/` on every rebuild.

## Automatic

- The theme's `install.sh` runs `rebuild-overrides.sh` on a fresh install.
- `check-on-login.sh` runs at login via
  `~/.config/autostart/exxos-plasmoid-check.desktop`. It compares Plasma's
  version against `~/.config/exxos-plasmoid-built-against` and **does nothing
  unless it changed** — which is every login except the one after an upgrade.
  On a change it rebuilds and shows a passive popup. Log:
  `~/.cache/exxos-plasmoid-check.log`.

## If a patch fails

Upstream rewrote that QML file. The widget falls back to **stock behaviour** —
the safe failure, not a broken panel. To fix, diff the new upstream file against
`superseded/<latest>/` to see what the old change was, reapply it by hand, then
regenerate the patch:

```bash
diff -u /usr/share/plasma/plasmoids/<id>/<file> ~/.local/share/plasma/plasmoids/<id>/<file> \
  > patches/<id>__<file>.patch
```

Built against: see `BASE-VERSION.txt`.
