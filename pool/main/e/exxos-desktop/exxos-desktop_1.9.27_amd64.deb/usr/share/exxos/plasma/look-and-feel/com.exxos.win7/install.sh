#!/bin/bash
# Install the bundled parts of the Exxos Global Theme.
#
# WHY THIS SCRIPT EXISTS
# A KDE Global Theme's "defaults" file only names the Plasma style, window
# decoration, colour scheme and icon theme -- it does not carry them. If those
# named things are not present on the machine, switching to the theme silently
# falls back to defaults. This script places the bundled copies where each
# subsystem actually looks, so the package is genuinely portable.
#
# Run this ONCE on a new machine, then pick "Exxos" in
# System Settings -> Appearance -> Global Theme.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"

install_dir() {          # $1 = source dir, $2 = destination parent
    [ -d "$1" ] || return 0
    mkdir -p "$2"
    cp -a "$1" "$2/"
    echo "  installed $(basename "$1") -> $2/"
}

echo "Installing Exxos theme components..."
install_dir "$HERE/bundle/aurorae/exposeair"            "$HOME/.local/share/aurorae/themes"
install_dir "$HERE/bundle/desktoptheme/Exxos"  "$HOME/.local/share/plasma/desktoptheme"

mkdir -p "$HOME/.local/share/color-schemes"
cp "$HERE/bundle/color-schemes/Exxos.colors" "$HOME/.local/share/color-schemes/"
echo "  installed Exxos.colors -> $HOME/.local/share/color-schemes/"

# --- icon theme: referenced by name, NOT bundled (532 MB) ---
ICON="Win7-plasma5up-scalable-icontheme-blackysgate.de"
if [ -d "$HOME/.local/share/icons/$ICON" ] || [ -d "/usr/share/icons/$ICON" ]; then
    echo "  icon theme '$ICON' found"
else
    echo
    echo "  WARNING: icon theme '$ICON' is NOT installed."
    echo "  It is 532 MB and is deliberately not bundled. Copy it to"
    echo "    ~/.local/share/icons/$ICON"
    echo "  from the source machine, or icons will fall back to the system theme."
fi

# --- widget style: provided by the distro, not by this theme ---
# plastique is used rather than cde/motif: cde does not highlight menu items on
# mouse-over (that is Motif behaviour, not a colour problem), while plastique
# looks near-identical under this colour scheme and highlights correctly.
if ! ls /usr/lib/*/qt5/plugins/styles/ 2>/dev/null | grep -qi 'plastique'; then
    echo
    echo "  WARNING: the 'plastique' widget style was not found."
    echo "  Install it with:  sudo apt install qt5-style-plugin-plastique"
    echo "  Without it the widget style will fall back to the system default."
fi

# --- panel widget overrides ------------------------------------------------
# The quick-launch spacing and start-menu styling are QML changes to three
# plasmoids. A plasmoid in ~/.local shadows the system one ENTIRELY, so these
# are rebuilt from whatever Plasma is installed here, rather than shipping a
# frozen copy of someone else's Plasma version.
if [ -x "$HERE/bundle/plasmoid-patches/rebuild-overrides.sh" ]; then
    echo
    echo "Applying panel widget patches..."
    "$HERE/bundle/plasmoid-patches/rebuild-overrides.sh" || {
        echo "  Some patches did not apply -- those widgets keep stock behaviour."
        echo "  That is the safe outcome; see plasmoid-patches/README for reapplying."
    }
fi

# --- keep them in step with future Plasma upgrades -------------------------
mkdir -p "$HOME/.config/autostart"
cat > "$HOME/.config/autostart/exxos-plasmoid-check.desktop" <<AUTOSTART
[Desktop Entry]
Type=Application
Name=Exxos panel widget check
Comment=Rebuild the Exxos plasmoid overrides if Plasma has been upgraded
Exec=$HERE/bundle/plasmoid-patches/check-on-login.sh
Terminal=false
X-KDE-autostart-phase=2
NoDisplay=true
AUTOSTART
echo "  login check installed (rebuilds the overrides if Plasma is upgraded)"

echo
echo "Done. Now select 'Exxos' in System Settings -> Appearance -> Global Theme."
